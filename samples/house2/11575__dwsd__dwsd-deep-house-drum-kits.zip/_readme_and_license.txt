Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by DWSD ( http://www.freesound.org/people/DWSD/  )
You can find this pack online at: http://www.freesound.org/people/DWSD/packs/11575/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 183125__dwsd__prc-dust808popperc.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183125/
    * license: Attribution
  * 183124__dwsd__prc-dust808tomlow.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183124/
    * license: Attribution
  * 183123__dwsd__prc-appetizer.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183123/
    * license: Attribution
  * 183122__dwsd__prc-appetom.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183122/
    * license: Attribution
  * 183121__dwsd__prc-detailedperk.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183121/
    * license: Attribution
  * 183120__dwsd__prc-dust808clav.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183120/
    * license: Attribution
  * 183119__dwsd__hat-detailedopen909.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183119/
    * license: Attribution
  * 183118__dwsd__hat-doitliveopenhat.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183118/
    * license: Attribution
  * 183117__dwsd__hat-dust808.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183117/
    * license: Attribution
  * 183115__dwsd__prc-appet909.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183115/
    * license: Attribution
  * 183114__dwsd__snr-appetizer.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183114/
    * license: Attribution
  * 183113__dwsd__rim-doitlivebias.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183113/
    * license: Attribution
  * 183112__dwsd__snr-detailroom.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183112/
    * license: Attribution
  * 183111__dwsd__snr-bod.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183111/
    * license: Attribution
  * 183110__dwsd__ride-dust808.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183110/
    * license: Attribution
  * 183109__dwsd__prc-phat909roomtom.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183109/
    * license: Attribution
  * 183108__dwsd__rim-boda.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183108/
    * license: Attribution
  * 183107__dwsd__rim-909analog.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183107/
    * license: Attribution
  * 183106__dwsd__snr-doitlive.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183106/
    * license: Attribution
  * 183105__dwsd__hat-appetizer.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183105/
    * license: Attribution
  * 183104__dwsd__hat-bodacious.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183104/
    * license: Attribution
  * 183103__dwsd__clp-appetizer.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183103/
    * license: Attribution
  * 183102__dwsd__clp-bodacious.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183102/
    * license: Attribution
  * 183101__dwsd__clp-detailed.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183101/
    * license: Attribution
  * 183100__dwsd__clp-dust808.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183100/
    * license: Attribution
  * 183099__dwsd__bd-bodacious.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183099/
    * license: Attribution
  * 183098__dwsd__bd-detailed.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183098/
    * license: Attribution
  * 183097__dwsd__bd-doitlive.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183097/
    * license: Attribution
  * 183096__dwsd__bd-dust808.wav
    * url: http://www.freesound.org/people/DWSD/sounds/183096/
    * license: Attribution

